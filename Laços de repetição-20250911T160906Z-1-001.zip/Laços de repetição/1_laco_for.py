import os 
os.system('cls')

for i in range (5):
    print("Marta")
