import streamlit as st

st.title("BOLETIM")

media = st.number_input("Informe a média do aluno: ", min_value=0, max_value=10)

if st.button("RESULTADO"):
    if media >= 7:
        st.success("APROVADO! :)")
    else:
        st.error("REPROVADO! :(")
else:
    st.info("Por favor, informe a média do aluno.")

# success - verde
# warning - amarelo
# info - azul
# error - vermelho