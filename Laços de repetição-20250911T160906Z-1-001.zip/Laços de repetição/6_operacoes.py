import streamlit as st

st.title("OPERAÇÕES")

num1 = st.number_input("Informe um número: ")
num2 = st.number_input("Informe outro número: ")

media = (num1 + num2) / 2
soma = num1 + num2
produto = num1 * num2
maior = max(num1, num2)
menor = min(num1, num2)

if st.button ("CALCULAR"):
    if num1 and num2:
        st.write("Média: ", media)
        st.write("Soma: ", soma)
        st.write("Produto: ", produto)
        st.write("Maior número: ", maior)
        st.write("Menor número: ", menor)
else:
    st.info("É preciso informar os números para fazer os calculos!")