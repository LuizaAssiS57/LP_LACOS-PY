import streamlit as st
import time

st.title("NÚMEROS PARES")

st.header("Contagem de números pares entre 100 e 120.")

if st.button("INICIAR"):
    for i in range(100, 121, 2):
        st.write(i)
        time.sleep(1)
    st.header("FIM")